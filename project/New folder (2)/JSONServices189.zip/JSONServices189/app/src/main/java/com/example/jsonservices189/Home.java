package com.example.jsonservices189;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.widget.ListAdapter;
import android.widget.ListView;
import android.widget.SimpleAdapter;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;
import java.util.ArrayList;
import java.util.HashMap;


public class Home extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_home);

        String jsonStr = getListData();
        try{
            ArrayList<HashMap<String, String>> userList = new ArrayList<>();
            ListView lv = (ListView) findViewById(R.id.user_list);
            JSONObject jObj = new JSONObject(jsonStr);
            JSONArray jsonArry = jObj.getJSONArray("users");
            for(int i=0;i<jsonArry.length();i++){
                HashMap<String,String> user = new HashMap<>();
                JSONObject obj = jsonArry.getJSONObject(i);
                user.put("name",obj.getString("name"));
                user.put("designation",obj.getString("designation"));
                user.put("location",obj.getString("location"));
                userList.add(user);
            }
            ListAdapter adapter = new SimpleAdapter(Home.this, userList, R.layout.list_row,new String[]{"name","designation","location"}, new int[]{R.id.name, R.id.designation, R.id.location});
            lv.setAdapter(adapter);
        }
        catch (JSONException ex){
            Log.e("JsonParser Example","unexpected JSON exception", ex);
        }
    }
    private String getListData() {
        String jsonStr = "{ \"users\" :[" +
                "{\"name\":\"Virat Kohli\",\"designation\":\"Batsman(Captain)\",\"location\":\"Mumbai\"}" +
                ",{\"name\":\"M S Dhoni\",\"designation\":\"Batsman(Wicket-keeper)\",\"location\":\"Ranchi\"}" +
                ",{\"name\":\"Rohit Sharma\",\"designation\":\"Batsman\",\"location\":\"Mumbai\"}" +
                ",{\"name\":\"Hardik Pandya\",\"designation\":\"All-rounder\",\"location\":\"Surat\"}" +
                ",{\"name\":\"Jasprit Bumrah\",\"designation\":\"Bowler\",\"location\":\"Ahemdabad\"}" +
                ",{\"name\":\"Shikhar Dhawan\",\"designation\":\"Batsman\",\"location\":\"Delhi\"}" +
                ",{\"name\":\"Ravichandran Ashwin\",\"designation\":\"Bowler\",\"location\":\"Chennai\"}" +
                ",{\"name\":\"Bhuvneshwar Kumar\",\"designation\":\"Bowler\",\"location\":\"Meerut\"}" +
                ",{\"name\":\"Rishabh Pant\",\"designation\":\"Batsman\",\"location\":\"Uttarakhand\"}] }";
        return jsonStr;

    }
}
